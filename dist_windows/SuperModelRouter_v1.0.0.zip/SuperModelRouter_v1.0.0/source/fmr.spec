# -*- mode: python ; coding: utf-8 -*-
"""
free-model-router PyInstaller spec
打包: pyinstaller fmr.spec

产出: dist/free-model-router.exe (单文件, 含 Python runtime + 所有依赖)
"""
from PyInstaller.utils.hooks import collect_data_files

block_cipher = None

# 收集 fmr 包内的所有 .py + config 模板
fmr_datas = [
    ('free_model_router/config.yaml.example', 'free_model_router'),
]

# free_model_router 是个纯 stdlib 包, 第三方依赖是 httpx + pyyaml
hiddenimports = [
    'free_model_router',
    'free_model_router.config',
    'free_model_router.discovery',
    'free_model_router.filter',
    'free_model_router.main',
    'free_model_router.provider',
    'free_model_router.router',
    'free_model_router.server',
    'httpx',
    'yaml',
]

a = Analysis(
    ['run_fmr_pyinstaller.py'],
    pathex=[],
    binaries=[],
    datas=fmr_datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        # 显式排除大模块, 减小 .exe 体积
        'tkinter', 'test', 'unittest', 'pydoc_data',
        'numpy', 'pandas', 'scipy', 'matplotlib',
        'IPython', 'jupyter', 'notebook',
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='free-model-router',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,        # UPX 压缩, 减小体积 (如可用)
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,    # fmr 是命令行 server, 保留控制台
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,       # 如有 .ico 可填
)
